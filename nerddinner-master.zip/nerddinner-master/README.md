Nerd Dinner
===========

Copy of original ASP.NET MVC 4 source code for http://nerddinner.com

The Open Source ASP.NET MVC Project that helps nerds and computer people plan get-togethers. You can see the site running LIVE at http://www.nerddinner.com. This project's goal is to create the best website for Technology People to host their Lunches, Flashmobs, Dinners and informal get-togethers.

The original tutorial no longer applies exactly, as it was written a few years ago for an older version of MVC. That said, it can still be a good learning tool so you can download a 185-page free PDF walkthrough loaded with code and screenshots at http://tinyurl.com/aspnetmvc.# nerddinner
